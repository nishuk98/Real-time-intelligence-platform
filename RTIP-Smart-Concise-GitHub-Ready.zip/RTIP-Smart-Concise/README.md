# Real-Time Intelligence Platform (RTIP)

RTIP retrieves recent news and generates AI-powered intelligence.

## Features
- Location and topic selection
- Smart Concise Intelligence Mode
- 2–3 sentence quick answer
- 3–5 key points
- Important source links
- Optional detailed report
- Google Colab compatible
- Streamlit Cloud deployable

## Local setup

```bash
pip install -r requirements.txt
```

Set environment variables:

```bash
export NEWSDATA_API_KEY="your_newsdata_key"
export GEMINI_API_KEY="your_gemini_key"
```

Run:

```bash
streamlit run app.py
```

## Streamlit Cloud

Add these secrets in App settings:

```toml
NEWSDATA_API_KEY = "your_newsdata_key"
GEMINI_API_KEY = "your_gemini_key"
```

Never commit API keys.
