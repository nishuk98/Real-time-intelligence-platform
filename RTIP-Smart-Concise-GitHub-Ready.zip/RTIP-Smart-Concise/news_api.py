import os
import requests
import streamlit as st

BASE_URL = "https://newsdata.io/api/1/latest"


def get_secret(name: str) -> str:
    value = os.getenv(name)
    if value:
        return value

    try:
        value = st.secrets.get(name)
        if value:
            return value
    except Exception:
        pass

    return ""


def fetch_news(query: str, country: str = "", language: str = "en",
               limit: int = 15):
    api_key = get_secret("NEWSDATA_API_KEY")

    if not api_key:
        raise ValueError(
            "NEWSDATA_API_KEY is missing. Add it to environment variables "
            "or Streamlit Secrets."
        )

    params = {
        "apikey": api_key,
        "q": query,
        "language": language,
        "size": min(max(limit, 1), 50),
    }

    if country and country != "Worldwide":
        params["country"] = country

    response = requests.get(BASE_URL, params=params, timeout=30)
    response.raise_for_status()
    data = response.json()

    if data.get("status") != "success":
        raise RuntimeError(data.get("message", "News API request failed."))

    articles = []

    for item in data.get("results", []):
        articles.append({
            "title": item.get("title") or "Untitled article",
            "description": item.get("description") or "",
            "source": item.get("source_name") or item.get("source_id") or "Unknown source",
            "published": item.get("pubDate") or "Unknown date",
            "url": item.get("link") or "",
            "image_url": item.get("image_url") or "",
        })

    return articles
