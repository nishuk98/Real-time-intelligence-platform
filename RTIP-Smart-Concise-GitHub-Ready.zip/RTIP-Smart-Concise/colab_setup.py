# Run these commands in Google Colab

# Cell 1:
# !pip install -q -r requirements.txt

# Cell 2:
# !git clone https://github.com/sizzlingish/Real-Time-Intelligence-Platform.git
# %cd Real-Time-Intelligence-Platform

# Cell 3:
# import os
# from getpass import getpass
# os.environ["NEWSDATA_API_KEY"] = getpass("NewsData.io API key: ")
# os.environ["GEMINI_API_KEY"] = getpass("Gemini API key: ")

# Cell 4:
# !streamlit run app.py --server.port 8501 &>/content/rtip.log &

# Cell 5:
# !pip install -q pyngrok
# from pyngrok import ngrok
# print(ngrok.connect(8501))
