import streamlit as st

from news_api import fetch_news
from retrieval import retrieve_articles
from ai import (
    generate_concise_intelligence,
    generate_intelligence,
)


st.set_page_config(
    page_title="RTIP - Real-Time Intelligence Platform",
    page_icon="🛰️",
    layout="wide",
)


def render_sources(articles):
    st.subheader("🔗 Important Sources")

    for article in articles:
        title = article.get("title", "Untitled")
        source = article.get("source", "Unknown source")
        published = article.get("published", "Unknown date")
        url = article.get("url", "")

        st.markdown(f"**{title}**")
        st.caption(f"{source} • {published}")

        if url:
            st.markdown(f"[Read original article]({url})")

        st.divider()


st.title("🛰️ Real-Time Intelligence Platform")
st.write(
    "Select a location and topic to receive concise or detailed "
    "AI-powered intelligence from recent news."
)

with st.sidebar:
    st.header("⚙️ RTIP Settings")

    location = st.selectbox(
        "Select Location",
        [
            "Worldwide",
            "Pakistan",
            "India",
            "United States",
            "United Kingdom",
            "China",
            "Hyderabad, Pakistan",
            "Karachi, Pakistan",
            "Islamabad, Pakistan",
        ],
    )

    topic = st.selectbox(
        "Select Topic",
        [
            "Artificial Intelligence",
            "Technology",
            "Politics",
            "Business",
            "Education",
            "Health",
            "Sports",
            "Climate",
            "Cybersecurity",
            "World News",
        ],
    )

    answer_mode = st.radio(
        "Answer Mode",
        [
            "⚡ Smart Concise Intelligence",
            "📄 Detailed Intelligence Report",
        ],
    )

    article_limit = st.slider(
        "Articles to retrieve",
        min_value=5,
        max_value=20,
        value=15,
    )

question = st.chat_input(
    "Ask a question about the selected location and topic..."
)

if question:
    st.chat_message("user").write(question)

    with st.chat_message("assistant"):
        try:
            search_query = f"{location} {topic} {question}"

            with st.spinner("🔎 Searching current news..."):
                articles = fetch_news(
                    query=search_query,
                    country="",
                    language="en",
                    limit=article_limit,
                )

            if not articles:
                st.warning("No relevant news articles were found.")
                st.stop()

            with st.spinner("🧠 Selecting relevant articles..."):
                relevant_articles = retrieve_articles(
                    articles,
                    question,
                    max_articles=8,
                )

            if not relevant_articles:
                st.warning("No relevant articles were found.")
                st.stop()

            with st.spinner("🤖 Generating intelligence..."):
                if answer_mode == "⚡ Smart Concise Intelligence":
                    answer = generate_concise_intelligence(
                        question=question,
                        articles=relevant_articles,
                        location=location,
                        topic=topic,
                    )
                else:
                    answer = generate_intelligence(
                        question=question,
                        articles=relevant_articles,
                        location=location,
                        topic=topic,
                    )

            st.markdown(answer)
            render_sources(relevant_articles)

        except Exception as error:
            st.error("The request could not be completed.")
            st.exception(error)
