import re
from collections import Counter


def normalize(text):
    return re.sub(r"[^a-z0-9\s]", " ", (text or "").lower())


def tokenize(text):
    return set(normalize(text).split())


def article_text(article):
    return " ".join([
        article.get("title", ""),
        article.get("description", ""),
        article.get("source", ""),
    ])


def retrieve_articles(articles, question, max_articles=8):
    if not articles:
        return []

    query_terms = tokenize(question)
    scored = []

    for index, article in enumerate(articles):
        terms = tokenize(article_text(article))
        overlap = len(query_terms.intersection(terms))
        title_overlap = len(query_terms.intersection(
            tokenize(article.get("title", ""))
        ))
        score = overlap + (title_overlap * 2)

        scored.append((score, index, article))

    scored.sort(key=lambda item: (item[0], -item[1]), reverse=True)

    selected = []
    seen = set()

    for score, index, article in scored:
        url = article.get("url", "")
        title = normalize(article.get("title", ""))

        identity = url or title
        if identity in seen:
            continue

        seen.add(identity)
        selected.append(article)

        if len(selected) >= max_articles:
            break

    return selected
