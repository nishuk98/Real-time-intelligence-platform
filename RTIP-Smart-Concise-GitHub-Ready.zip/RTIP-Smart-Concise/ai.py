import os
from google import genai
import streamlit as st


def get_api_key():
    key = os.getenv("GEMINI_API_KEY")
    if key:
        return key

    try:
        key = st.secrets.get("GEMINI_API_KEY")
        if key:
            return key
    except Exception:
        pass

    raise ValueError(
        "GEMINI_API_KEY is missing. Add it to environment variables "
        "or Streamlit Secrets."
    )


def get_client():
    return genai.Client(api_key=get_api_key())


def build_news_context(articles):
    if not articles:
        return "No articles available."

    blocks = []

    for number, article in enumerate(articles, 1):
        blocks.append(f"""ARTICLE {number}
Title: {article.get('title', 'Untitled')}
Source: {article.get('source', 'Unknown')}
Published: {article.get('published', 'Unknown')}
Description: {article.get('description', '')}
URL: {article.get('url', '')}
""")

    return "\n".join(blocks)


def generate_concise_intelligence(question, articles, location, topic):
    client = get_client()
    context = build_news_context(articles)

    prompt = f"""
You are the Smart Concise Intelligence Analyst for RTIP.

LOCATION: {location}
TOPIC: {topic}
USER QUESTION: {question}

NEWS ARTICLES:
{context}

Use only the supplied articles. Do not invent facts or URLs.
If evidence is insufficient, say so clearly.
Write a concise, useful answer.

Return exactly this Markdown structure:

### ⚡ Quick Answer
Write 2–3 sentences.

### 🔎 Key Points
- Write 3–5 important points.
- Do not repeat information.
- Include dates or numbers only when supported.

### 🔗 Important Sources
- [Article title](original URL)
- [Article title](original URL)

Only include source URLs supplied in the articles.
"""

    response = client.models.generate_content(
        model="gemini-2.5-flash",
        contents=prompt,
    )

    return response.text or "No answer was generated."


def generate_intelligence(question, articles, location, topic):
    client = get_client()
    context = build_news_context(articles)

    prompt = f"""
You are the detailed intelligence analyst for RTIP.

LOCATION: {location}
TOPIC: {topic}
USER QUESTION: {question}

NEWS ARTICLES:
{context}

Use only the supplied articles. Do not invent facts or URLs.
Mention uncertainty and source conflicts when present.

Return:

### 📰 Intelligence Summary
### 🔎 Key Developments
### ⚖️ Source Comparison
### 📌 Why It Matters
### 🕐 Latest Information
### 🔗 Sources

Keep the report factual and readable.
"""

    response = client.models.generate_content(
        model="gemini-2.5-flash",
        contents=prompt,
    )

    return response.text or "No report was generated."
